Code Style
=======
* Google C++ Style
* Indent adjusted to 4 characters
* Line width adjusted to 120 characters

