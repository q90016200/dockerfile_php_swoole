pg_dump --host=127.0.0.1 --port=5432 --username=postgres --password --dbname=test> tests/testdb.sql
