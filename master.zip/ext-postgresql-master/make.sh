phpize --clean
phpize
./configure
make -j install
